using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using ServoControl;

namespace SerialPortReader
{
   [Serializable]
   public class Preferences : object
   {
      public string SerialPortName;
      public uint BaudRate;
      public System.IO.Ports.Parity parity;
      public uint DataBits;
      public System.IO.Ports.StopBits StopBits;
      public bool ShowInputWindow;
      public bool ShowTimeStamp;
      public bool HideBlankLines;

      public Preferences()
      {
      }
   }

   class AppSettingSave
   {
      private const String STR_INI_FILE = "serialPortReader.dat";
      private String m_strPrefsFilePath = "";
      private Preferences m_Preferences;

      public AppSettingSave()
      {
         m_Preferences = new Preferences();
         SetDefaultFilePaths();
      }

      private void SetDefaultFilePaths()
      {
         m_strPrefsFilePath = Application.UserAppDataPath + "\\" + STR_INI_FILE;

         if (!Directory.Exists(Application.UserAppDataPath))
            Directory.CreateDirectory(Application.UserAppDataPath);
      }


      /******************************************************************************
      ** In:   See .NET Documentation
      ** Out:  N/A
      **
      ** Decription:
      **    Load app settings.
      **
      *******************************************************************************/
      public void LoadAppSettings(SerialPortSelectionControl spsc, Form1 form1)
      {
         // First determine if the file exists
         if (!File.Exists(m_strPrefsFilePath))
            return;

         // Open the prefs file for reading
         FileStream      inStream  = new FileStream(m_strPrefsFilePath, FileMode.Open, FileAccess.Read);
         BinaryFormatter binReader = new BinaryFormatter();

         // Load file into the arraylist
         try
         {
            m_Preferences = (Preferences)binReader.Deserialize(inStream);
         }
         catch
         {
            MessageBox.Show("Corrupted or incompatible preferences file.", "Application Preferences",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
            inStream.Close();
            return;
         }

         // Close file
         inStream.Close();

         // Put up the settings
         spsc.SelectedBaudRate = m_Preferences.BaudRate;
         spsc.SelectedDataBits = m_Preferences.DataBits;
         spsc.SelectedParity   = m_Preferences.parity;
         spsc.SelectedPort     = m_Preferences.SerialPortName;
         spsc.SelectedStopBits = m_Preferences.StopBits;

         form1.IsInputWindowVisible = m_Preferences.ShowInputWindow;
         form1.IsTimeStampShown     = m_Preferences.ShowTimeStamp;
         form1.HideBlankLines       = m_Preferences.HideBlankLines;
      }


      // ******************************************************************************
      // In:   N/A
      // Out:  N/A
      //
      // Decription:
      //    Save app settings to INI file.
      //
      // ******************************************************************************
      public void SaveAppSettings(SerialPortSelectionControl spsc, Form1 form1)
      {
         // Save settings
         m_Preferences.BaudRate       = spsc.SelectedBaudRate;
         m_Preferences.DataBits       = spsc.SelectedDataBits;
         m_Preferences.parity         = spsc.SelectedParity;
         m_Preferences.SerialPortName = spsc.SelectedPort;
         m_Preferences.StopBits       = spsc.SelectedStopBits;

         m_Preferences.ShowInputWindow = form1.IsInputWindowVisible;
         m_Preferences.ShowTimeStamp   = form1.IsTimeStampShown;
         m_Preferences.HideBlankLines = form1.HideBlankLines;

         // Open the prefs file for saving
         FileStream outstream      = new FileStream(m_strPrefsFilePath, FileMode.OpenOrCreate, FileAccess.Write);
         BinaryFormatter binWriter = new BinaryFormatter();

         // Save the object to the file
         binWriter.Serialize(outstream, m_Preferences);

         // Close file
         outstream.Close();
      }
   }
}
