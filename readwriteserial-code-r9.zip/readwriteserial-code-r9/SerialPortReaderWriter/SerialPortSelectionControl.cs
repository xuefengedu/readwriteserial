﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace ServoControl
{
   public partial class SerialPortSelectionControl : UserControl
   {
      public string SelectedPort
      {
         get { return cbSerialPorts.Text; }
         set { cbSerialPorts.Text = value; }
      }

      public uint SelectedBaudRate
      {
         get
         { 
            uint returnValue = 0;

            if (uint.TryParse(cbBaudRate.Text, out returnValue))
               return returnValue;
            else
               return 0;
         }
         set { cbBaudRate.Text = value.ToString(); }
      }

      public uint SelectedDataBits
      {
         get { return uint.Parse(cbDataBits.Text); }
         set { cbDataBits.Text = value.ToString(); }
      }

      public System.IO.Ports.Parity SelectedParity
      {
         get { return (System.IO.Ports.Parity)cbParity.SelectedItem; }
         set { cbParity.SelectedIndex = cbParity.Items.IndexOf(value); }
      }

      public System.IO.Ports.StopBits SelectedStopBits
      {
         get { return (System.IO.Ports.StopBits)cbStopBits.SelectedItem; }
         set { cbStopBits.SelectedIndex = cbStopBits.Items.IndexOf(value); }
      }

      public SerialPortSelectionControl()
      {
         InitializeComponent();

         SetBaudRatesInForm();
         SetStopBitsInForm();
         SetDefaultValues();
         FindAvailableSerialPorts();
      }

      private void SetDefaultValues()
      {
         const int eightBits = 8;

         this.cbDataBits.SelectedIndex = this.cbDataBits.Items.IndexOf(eightBits.ToString());
         this.cbParity.SelectedIndex = this.cbParity.Items.IndexOf(System.IO.Ports.Parity.None);
         this.cbStopBits.SelectedIndex = this.cbStopBits.Items.IndexOf(System.IO.Ports.StopBits.One);
      }

      private void SetStopBitsInForm()
      {
         this.cbStopBits.Items.Add(System.IO.Ports.StopBits.None);
         this.cbStopBits.Items.Add(System.IO.Ports.StopBits.One);
         this.cbStopBits.Items.Add(System.IO.Ports.StopBits.OnePointFive);
         this.cbStopBits.Items.Add(System.IO.Ports.StopBits.Two);
      }

      private void SetBaudRatesInForm()
      {
         this.cbParity.Items.Add(System.IO.Ports.Parity.Even);
         this.cbParity.Items.Add(System.IO.Ports.Parity.Mark);
         this.cbParity.Items.Add(System.IO.Ports.Parity.None);
         this.cbParity.Items.Add(System.IO.Ports.Parity.Odd);
         this.cbParity.Items.Add(System.IO.Ports.Parity.Space);
      }

      public void FindAvailableSerialPorts()
      {
         string[] theSerialPortNames = System.IO.Ports.SerialPort.GetPortNames();

         foreach (string port in theSerialPortNames)
            this.cbSerialPorts.Items.Add(port.TrimEnd(new char[] { 'w' }));

         if (this.cbSerialPorts.Items.Count > 0)
            this.cbSerialPorts.SelectedIndex = 0;
      }

      public bool ValidValues()
      {
         return (this.cbStopBits.SelectedIndex >= 0 && this.cbBaudRate.SelectedIndex >= 0 &&
                 this.cbSerialPorts.SelectedIndex >= 0 && this.cbParity.SelectedIndex >= 0 &&
                 this.cbDataBits.SelectedIndex >= 0);
      }


      System.IO.Ports.SerialPort serialPort1 = null;

      public SerialPort SerialPortInUse
      {
         get { return serialPort1; }
      }

      public event EventHandler SerialPortConnectClicked;

      private void btnConnect_Click(object sender, EventArgs e)
      {
         try
         {
            if (serialPort1 == null)
               serialPort1 = new System.IO.Ports.SerialPort();

            if (btnConnect.Text == "Disconnect")
            {
               serialPort1.Close();
               btnConnect.Text = "Connect";
               EnableComboBoxes(true);
            }
            else
            {
               if (SetupSerialPort())
               {
                  serialPort1.Open();

                  btnConnect.Text = "Disconnect";
                  EnableComboBoxes(false);
               }
            }

            if (this.SerialPortConnectClicked != null)
               this.SerialPortConnectClicked(this, e);
         }
         catch (IOException ioException)
         {
            if(!serialPort1.IsOpen)
               btnConnect.Text = "Connect";

            MessageBox.Show(this, ioException.Message, "I/O Exception", MessageBoxButtons.OK, MessageBoxIcon.Error,
                             MessageBoxDefaultButton.Button1);
         }
         catch (UnauthorizedAccessException uaException)
         {
            if (!serialPort1.IsOpen)
               btnConnect.Text = "Connect";

            MessageBox.Show(this, uaException.Message, "Unauthorized Access Exception", MessageBoxButtons.OK, MessageBoxIcon.Error,
                             MessageBoxDefaultButton.Button1);
         }
         catch (ArgumentOutOfRangeException argOutOfRangeException)
         {
            if (!serialPort1.IsOpen)
               btnConnect.Text = "Connect";

            MessageBox.Show(this, argOutOfRangeException.Message, "Argument Exception", MessageBoxButtons.OK, MessageBoxIcon.Error,
                             MessageBoxDefaultButton.Button1);
         }
      }

      private bool SetupSerialPort()
      {
         if (!CheckForValidValues())
         {
            MessageBox.Show("Please select all values before connecting\n", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
         }

         if (serialPort1 != null && !serialPort1.IsOpen)
         {
            serialPort1.PortName = cbSerialPorts.Text;
            serialPort1.BaudRate = int.Parse(cbBaudRate.Text.ToString());
            serialPort1.StopBits = (StopBits)cbStopBits.SelectedItem;
            serialPort1.DataBits = int.Parse(cbDataBits.Items[cbDataBits.SelectedIndex].ToString());
            serialPort1.Parity = (Parity)cbParity.SelectedItem;

            return true;
         }

         return false;
      }

      private bool CheckForValidValues()
      {
         return (cbSerialPorts.Text.Length > 0 && cbBaudRate.Text.Length > 0 &&
                 cbStopBits.Text.Length > 0 && cbDataBits.Text.Length > 0 &&
                 cbParity.Text.Length > 0);
      }

      private void EnableComboBoxes(bool enable)
      {
         cbDataBits.Enabled = enable;
         cbParity.Enabled = enable;
         cbSerialPorts.Enabled = enable;
         cbBaudRate.Enabled = enable;
         cbStopBits.Enabled = enable;
      }


      internal void Disconnect()
      {
         if (serialPort1 != null && serialPort1.IsOpen)
            serialPort1.Close();
      }
   }
}
