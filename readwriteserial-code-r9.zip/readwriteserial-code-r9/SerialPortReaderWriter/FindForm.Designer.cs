namespace SerialPortWriterReader.SerialPortReaderWriter
{
   partial class FindForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindForm));
         this.pbWrap = new System.Windows.Forms.PictureBox();
         this.btnSearch = new System.Windows.Forms.Button();
         this.tbSearchText = new System.Windows.Forms.TextBox();
         this.btnClose = new System.Windows.Forms.Button();
         ((System.ComponentModel.ISupportInitialize)(this.pbWrap)).BeginInit();
         this.SuspendLayout();
         // 
         // pbWrap
         // 
         this.pbWrap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
         this.pbWrap.Image = ((System.Drawing.Image)(resources.GetObject("pbWrap.Image")));
         this.pbWrap.Location = new System.Drawing.Point(326, 13);
         this.pbWrap.Name = "pbWrap";
         this.pbWrap.Size = new System.Drawing.Size(18, 14);
         this.pbWrap.TabIndex = 71;
         this.pbWrap.TabStop = false;
         this.pbWrap.Visible = false;
         // 
         // btnSearch
         // 
         this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
         this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.btnSearch.Location = new System.Drawing.Point(245, 9);
         this.btnSearch.Name = "btnSearch";
         this.btnSearch.Size = new System.Drawing.Size(75, 23);
         this.btnSearch.TabIndex = 70;
         this.btnSearch.Text = "Search";
         this.btnSearch.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
         this.btnSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FindForm_KeyDown);
         // 
         // tbSearchText
         // 
         this.tbSearchText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
         this.tbSearchText.Location = new System.Drawing.Point(9, 10);
         this.tbSearchText.Name = "tbSearchText";
         this.tbSearchText.Size = new System.Drawing.Size(232, 20);
         this.tbSearchText.TabIndex = 69;
         this.tbSearchText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FindForm_KeyDown);
         // 
         // btnClose
         // 
         this.btnClose.Location = new System.Drawing.Point(139, 44);
         this.btnClose.Name = "btnClose";
         this.btnClose.Size = new System.Drawing.Size(75, 23);
         this.btnClose.TabIndex = 72;
         this.btnClose.Text = "Close";
         this.btnClose.UseVisualStyleBackColor = true;
         this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
         // 
         // FindForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(352, 76);
         this.Controls.Add(this.btnClose);
         this.Controls.Add(this.pbWrap);
         this.Controls.Add(this.btnSearch);
         this.Controls.Add(this.tbSearchText);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FindForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
         this.Text = "Find";
         this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FindForm_KeyDown);
         ((System.ComponentModel.ISupportInitialize)(this.pbWrap)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      internal System.Windows.Forms.PictureBox pbWrap;
      internal System.Windows.Forms.Button btnSearch;
      internal System.Windows.Forms.TextBox tbSearchText;
      private System.Windows.Forms.Button btnClose;
   }
}