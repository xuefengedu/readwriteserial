namespace Filter_Form
{
   partial class FilterForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.btnClearAll = new System.Windows.Forms.Button();
         this.btnCancel = new System.Windows.Forms.Button();
         this.tbAddPhrase = new System.Windows.Forms.TextBox();
         this.btnOk = new System.Windows.Forms.Button();
         this.btnRemove = new System.Windows.Forms.Button();
         this.btnAddIncluded = new System.Windows.Forms.Button();
         this.lbIncludeFilterPharses = new System.Windows.Forms.ListBox();
         this.lbExcludeFilterPharses = new System.Windows.Forms.ListBox();
         this.label1 = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.btnAddExcluded = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // btnClearAll
         // 
         this.btnClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnClearAll.Location = new System.Drawing.Point(82, 214);
         this.btnClearAll.Name = "btnClearAll";
         this.btnClearAll.Size = new System.Drawing.Size(72, 24);
         this.btnClearAll.TabIndex = 13;
         this.btnClearAll.Text = "Clear All";
         this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
         // 
         // btnCancel
         // 
         this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.btnCancel.Location = new System.Drawing.Point(179, 256);
         this.btnCancel.Name = "btnCancel";
         this.btnCancel.Size = new System.Drawing.Size(104, 24);
         this.btnCancel.TabIndex = 12;
         this.btnCancel.Text = "Cancel";
         // 
         // tbAddPhrase
         // 
         this.tbAddPhrase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.tbAddPhrase.Location = new System.Drawing.Point(4, 187);
         this.tbAddPhrase.Name = "tbAddPhrase";
         this.tbAddPhrase.Size = new System.Drawing.Size(167, 20);
         this.tbAddPhrase.TabIndex = 11;
         // 
         // btnOk
         // 
         this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.btnOk.Location = new System.Drawing.Point(67, 256);
         this.btnOk.Name = "btnOk";
         this.btnOk.Size = new System.Drawing.Size(104, 24);
         this.btnOk.TabIndex = 10;
         this.btnOk.Text = "OK";
         this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
         // 
         // btnRemove
         // 
         this.btnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnRemove.Location = new System.Drawing.Point(4, 214);
         this.btnRemove.Name = "btnRemove";
         this.btnRemove.Size = new System.Drawing.Size(72, 24);
         this.btnRemove.TabIndex = 9;
         this.btnRemove.Text = "Remove";
         this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
         // 
         // btnAddIncluded
         // 
         this.btnAddIncluded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnAddIncluded.Location = new System.Drawing.Point(179, 185);
         this.btnAddIncluded.Name = "btnAddIncluded";
         this.btnAddIncluded.Size = new System.Drawing.Size(82, 24);
         this.btnAddIncluded.TabIndex = 8;
         this.btnAddIncluded.Text = "Add Included";
         this.btnAddIncluded.Click += new System.EventHandler(this.btnAdd_Click);
         // 
         // lbIncludeFilterPharses
         // 
         this.lbIncludeFilterPharses.Location = new System.Drawing.Point(3, 16);
         this.lbIncludeFilterPharses.Name = "lbIncludeFilterPharses";
         this.lbIncludeFilterPharses.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
         this.lbIncludeFilterPharses.Size = new System.Drawing.Size(344, 69);
         this.lbIncludeFilterPharses.TabIndex = 7;
         // 
         // lbExcludeFilterPharses
         // 
         this.lbExcludeFilterPharses.Location = new System.Drawing.Point(4, 104);
         this.lbExcludeFilterPharses.Name = "lbExcludeFilterPharses";
         this.lbExcludeFilterPharses.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
         this.lbExcludeFilterPharses.Size = new System.Drawing.Size(344, 69);
         this.lbExcludeFilterPharses.TabIndex = 14;
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label1.Location = new System.Drawing.Point(5, 1);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(60, 13);
         this.label1.TabIndex = 15;
         this.label1.Text = "Included:";
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label2.Location = new System.Drawing.Point(5, 88);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(63, 13);
         this.label2.TabIndex = 16;
         this.label2.Text = "Excluded:";
         // 
         // btnAddExcluded
         // 
         this.btnAddExcluded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnAddExcluded.Location = new System.Drawing.Point(266, 185);
         this.btnAddExcluded.Name = "btnAddExcluded";
         this.btnAddExcluded.Size = new System.Drawing.Size(82, 24);
         this.btnAddExcluded.TabIndex = 17;
         this.btnAddExcluded.Text = "Add Excluded";
         this.btnAddExcluded.Click += new System.EventHandler(this.btnAddExcluded_Click);
         // 
         // FilterForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.CancelButton = this.btnCancel;
         this.ClientSize = new System.Drawing.Size(353, 289);
         this.Controls.Add(this.btnAddExcluded);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.lbExcludeFilterPharses);
         this.Controls.Add(this.btnClearAll);
         this.Controls.Add(this.btnCancel);
         this.Controls.Add(this.tbAddPhrase);
         this.Controls.Add(this.btnOk);
         this.Controls.Add(this.btnRemove);
         this.Controls.Add(this.btnAddIncluded);
         this.Controls.Add(this.lbIncludeFilterPharses);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.KeyPreview = true;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FilterForm";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "Filters";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      internal System.Windows.Forms.Button btnClearAll;
      internal System.Windows.Forms.Button btnCancel;
      internal System.Windows.Forms.TextBox tbAddPhrase;
      internal System.Windows.Forms.Button btnOk;
      internal System.Windows.Forms.Button btnRemove;
      internal System.Windows.Forms.Button btnAddIncluded;
      internal System.Windows.Forms.ListBox lbIncludeFilterPharses;
      internal System.Windows.Forms.ListBox lbExcludeFilterPharses;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Label label2;
      internal System.Windows.Forms.Button btnAddExcluded;
   }
}