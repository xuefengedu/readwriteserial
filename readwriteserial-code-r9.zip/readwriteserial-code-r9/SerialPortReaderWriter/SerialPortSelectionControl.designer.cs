﻿namespace ServoControl
{
    partial class SerialPortSelectionControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.cbSerialPorts = new System.Windows.Forms.ComboBox();
           this.lblSerialPort = new System.Windows.Forms.Label();
           this.lblSpeed = new System.Windows.Forms.Label();
           this.cbBaudRate = new System.Windows.Forms.ComboBox();
           this.cbParity = new System.Windows.Forms.ComboBox();
           this.label2 = new System.Windows.Forms.Label();
           this.cbDataBits = new System.Windows.Forms.ComboBox();
           this.label3 = new System.Windows.Forms.Label();
           this.cbStopBits = new System.Windows.Forms.ComboBox();
           this.label1 = new System.Windows.Forms.Label();
           this.btnConnect = new System.Windows.Forms.Button();
           this.SuspendLayout();
           // 
           // cbSerialPorts
           // 
           this.cbSerialPorts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.cbSerialPorts.BackColor = System.Drawing.SystemColors.Window;
           this.cbSerialPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
           this.cbSerialPorts.FormattingEnabled = true;
           this.cbSerialPorts.Location = new System.Drawing.Point(87, 20);
           this.cbSerialPorts.Name = "cbSerialPorts";
           this.cbSerialPorts.Size = new System.Drawing.Size(121, 21);
           this.cbSerialPorts.Sorted = true;
           this.cbSerialPorts.TabIndex = 0;
           // 
           // lblSerialPort
           // 
           this.lblSerialPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.lblSerialPort.AutoSize = true;
           this.lblSerialPort.Location = new System.Drawing.Point(87, 4);
           this.lblSerialPort.Name = "lblSerialPort";
           this.lblSerialPort.Size = new System.Drawing.Size(58, 13);
           this.lblSerialPort.TabIndex = 1;
           this.lblSerialPort.Text = "Serial Port:";
           // 
           // lblSpeed
           // 
           this.lblSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.lblSpeed.AutoSize = true;
           this.lblSpeed.Location = new System.Drawing.Point(215, 4);
           this.lblSpeed.Name = "lblSpeed";
           this.lblSpeed.Size = new System.Drawing.Size(61, 13);
           this.lblSpeed.TabIndex = 3;
           this.lblSpeed.Text = "Baud Rate:";
           // 
           // cbBaudRate
           // 
           this.cbBaudRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.cbBaudRate.FormattingEnabled = true;
           this.cbBaudRate.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
           this.cbBaudRate.Location = new System.Drawing.Point(215, 20);
           this.cbBaudRate.Name = "cbBaudRate";
           this.cbBaudRate.Size = new System.Drawing.Size(82, 21);
           this.cbBaudRate.TabIndex = 2;
           // 
           // cbParity
           // 
           this.cbParity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.cbParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
           this.cbParity.FormattingEnabled = true;
           this.cbParity.Location = new System.Drawing.Point(304, 20);
           this.cbParity.Name = "cbParity";
           this.cbParity.Size = new System.Drawing.Size(55, 21);
           this.cbParity.TabIndex = 5;
           // 
           // label2
           // 
           this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.label2.AutoSize = true;
           this.label2.Location = new System.Drawing.Point(304, 4);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(36, 13);
           this.label2.TabIndex = 6;
           this.label2.Text = "Parity:";
           // 
           // cbDataBits
           // 
           this.cbDataBits.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.cbDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
           this.cbDataBits.FormattingEnabled = true;
           this.cbDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
           this.cbDataBits.Location = new System.Drawing.Point(366, 20);
           this.cbDataBits.Name = "cbDataBits";
           this.cbDataBits.Size = new System.Drawing.Size(50, 21);
           this.cbDataBits.TabIndex = 7;
           // 
           // label3
           // 
           this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.label3.AutoSize = true;
           this.label3.Location = new System.Drawing.Point(366, 4);
           this.label3.Name = "label3";
           this.label3.Size = new System.Drawing.Size(53, 13);
           this.label3.TabIndex = 8;
           this.label3.Text = "Data Bits:";
           // 
           // cbStopBits
           // 
           this.cbStopBits.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.cbStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
           this.cbStopBits.FormattingEnabled = true;
           this.cbStopBits.Location = new System.Drawing.Point(423, 20);
           this.cbStopBits.Name = "cbStopBits";
           this.cbStopBits.Size = new System.Drawing.Size(52, 21);
           this.cbStopBits.TabIndex = 9;
           // 
           // label1
           // 
           this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
           this.label1.AutoSize = true;
           this.label1.Location = new System.Drawing.Point(423, 4);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(52, 13);
           this.label1.TabIndex = 10;
           this.label1.Text = "Stop Bits:";
           // 
           // btnConnect
           // 
           this.btnConnect.Location = new System.Drawing.Point(5, 18);
           this.btnConnect.Name = "btnConnect";
           this.btnConnect.Size = new System.Drawing.Size(75, 23);
           this.btnConnect.TabIndex = 11;
           this.btnConnect.Text = "Connect";
           this.btnConnect.UseVisualStyleBackColor = true;
           this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
           // 
           // SerialPortSelectionControl
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.AutoSize = true;
           this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
           this.Controls.Add(this.btnConnect);
           this.Controls.Add(this.label1);
           this.Controls.Add(this.cbStopBits);
           this.Controls.Add(this.label3);
           this.Controls.Add(this.cbDataBits);
           this.Controls.Add(this.label2);
           this.Controls.Add(this.cbParity);
           this.Controls.Add(this.lblSpeed);
           this.Controls.Add(this.cbBaudRate);
           this.Controls.Add(this.lblSerialPort);
           this.Controls.Add(this.cbSerialPorts);
           this.Name = "SerialPortSelectionControl";
           this.Size = new System.Drawing.Size(478, 44);
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbSerialPorts;
        private System.Windows.Forms.Label lblSerialPort;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.ComboBox cbParity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbDataBits;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbStopBits;
        private System.Windows.Forms.Label label1;
       private System.Windows.Forms.Button btnConnect;
    }
}
