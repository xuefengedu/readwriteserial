namespace SerialPortReader
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.lbDataWindow = new System.Windows.Forms.ListBox();
         this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
         this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.clearBusLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.cbPauseLog = new System.Windows.Forms.CheckBox();
         this.btnClearLogWindow = new System.Windows.Forms.Button();
         this.menuStrip1 = new System.Windows.Forms.MenuStrip();
         this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.saveLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
         this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.showTimestampToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.showInputLogWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.hideBlankLinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.lbWriteLog = new System.Windows.Forms.ListBox();
         this.textBox1 = new System.Windows.Forms.TextBox();
         this.btnSend = new System.Windows.Forms.Button();
         this.statusStrip1 = new System.Windows.Forms.StatusStrip();
         this.tsslConnectionStatus = new System.Windows.Forms.ToolStripStatusLabel();
         this.toolStripStatusLabelSeperator = new System.Windows.Forms.ToolStripStatusLabel();
         this.tsslFiltersSet = new System.Windows.Forms.ToolStripStatusLabel();
         this.splitContainer1 = new System.Windows.Forms.SplitContainer();
         this.btnFilter = new System.Windows.Forms.Button();
         this.serialPortSelectionControl1 = new ServoControl.SerialPortSelectionControl();
         this.contextMenuStrip1.SuspendLayout();
         this.menuStrip1.SuspendLayout();
         this.statusStrip1.SuspendLayout();
         this.splitContainer1.Panel1.SuspendLayout();
         this.splitContainer1.Panel2.SuspendLayout();
         this.splitContainer1.SuspendLayout();
         this.SuspendLayout();
         // 
         // lbDataWindow
         // 
         this.lbDataWindow.ContextMenuStrip = this.contextMenuStrip1;
         this.lbDataWindow.Dock = System.Windows.Forms.DockStyle.Fill;
         this.lbDataWindow.FormattingEnabled = true;
         this.lbDataWindow.HorizontalScrollbar = true;
         this.lbDataWindow.IntegralHeight = false;
         this.lbDataWindow.Location = new System.Drawing.Point(0, 0);
         this.lbDataWindow.Name = "lbDataWindow";
         this.lbDataWindow.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
         this.lbDataWindow.Size = new System.Drawing.Size(833, 296);
         this.lbDataWindow.TabIndex = 1;
         this.lbDataWindow.Leave += new System.EventHandler(this.lbDataWindow_Leave);
         this.lbDataWindow.Enter += new System.EventHandler(this.lbDataWindow_Enter);
         this.lbDataWindow.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lbDataWindow_KeyPress);
         // 
         // contextMenuStrip1
         // 
         this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.clearBusLogToolStripMenuItem});
         this.contextMenuStrip1.Name = "contextMenuStrip1";
         this.contextMenuStrip1.Size = new System.Drawing.Size(151, 48);
         this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
         // 
         // copyToolStripMenuItem
         // 
         this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
         this.copyToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
         this.copyToolStripMenuItem.Text = "Copy";
         this.copyToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem_Click);
         // 
         // clearBusLogToolStripMenuItem
         // 
         this.clearBusLogToolStripMenuItem.Name = "clearBusLogToolStripMenuItem";
         this.clearBusLogToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
         this.clearBusLogToolStripMenuItem.Text = "Clear Bus Log";
         // 
         // cbPauseLog
         // 
         this.cbPauseLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
         this.cbPauseLog.AutoSize = true;
         this.cbPauseLog.Location = new System.Drawing.Point(661, 428);
         this.cbPauseLog.Name = "cbPauseLog";
         this.cbPauseLog.Size = new System.Drawing.Size(103, 17);
         this.cbPauseLog.TabIndex = 2;
         this.cbPauseLog.Text = "Pause Data Log";
         this.cbPauseLog.UseVisualStyleBackColor = true;
         // 
         // btnClearLogWindow
         // 
         this.btnClearLogWindow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
         this.btnClearLogWindow.Location = new System.Drawing.Point(770, 425);
         this.btnClearLogWindow.Name = "btnClearLogWindow";
         this.btnClearLogWindow.Size = new System.Drawing.Size(75, 23);
         this.btnClearLogWindow.TabIndex = 3;
         this.btnClearLogWindow.Text = "Clear Log";
         this.btnClearLogWindow.UseVisualStyleBackColor = true;
         this.btnClearLogWindow.Click += new System.EventHandler(this.btnClearLogWindow_Click);
         // 
         // menuStrip1
         // 
         this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.helpToolStripMenuItem});
         this.menuStrip1.Location = new System.Drawing.Point(0, 0);
         this.menuStrip1.Name = "menuStrip1";
         this.menuStrip1.Size = new System.Drawing.Size(857, 24);
         this.menuStrip1.TabIndex = 4;
         this.menuStrip1.Text = "menuStrip1";
         // 
         // fileToolStripMenuItem
         // 
         this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveLogToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
         this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
         this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
         this.fileToolStripMenuItem.Text = "File";
         // 
         // saveLogToolStripMenuItem
         // 
         this.saveLogToolStripMenuItem.Image = global::SerialPortWriterReader.Properties.Resources.Floppy_unmount;
         this.saveLogToolStripMenuItem.Name = "saveLogToolStripMenuItem";
         this.saveLogToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
         this.saveLogToolStripMenuItem.Text = "Save Log";
         this.saveLogToolStripMenuItem.Click += new System.EventHandler(this.saveLogToolStripMenuItem_Click);
         // 
         // toolStripSeparator1
         // 
         this.toolStripSeparator1.Name = "toolStripSeparator1";
         this.toolStripSeparator1.Size = new System.Drawing.Size(126, 6);
         // 
         // exitToolStripMenuItem
         // 
         this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
         this.exitToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
         this.exitToolStripMenuItem.Text = "Exit";
         this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
         // 
         // editToolStripMenuItem
         // 
         this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findToolStripMenuItem});
         this.editToolStripMenuItem.Name = "editToolStripMenuItem";
         this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
         this.editToolStripMenuItem.Text = "Edit";
         // 
         // findToolStripMenuItem
         // 
         this.findToolStripMenuItem.Image = global::SerialPortWriterReader.Properties.Resources.Find;
         this.findToolStripMenuItem.Name = "findToolStripMenuItem";
         this.findToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
         this.findToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
         this.findToolStripMenuItem.Text = "Find";
         this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
         // 
         // viewToolStripMenuItem
         // 
         this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showTimestampToolStripMenuItem,
            this.showInputLogWindowToolStripMenuItem,
            this.hideBlankLinesToolStripMenuItem});
         this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
         this.viewToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
         this.viewToolStripMenuItem.Text = "View";
         // 
         // showTimestampToolStripMenuItem
         // 
         this.showTimestampToolStripMenuItem.Name = "showTimestampToolStripMenuItem";
         this.showTimestampToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
         this.showTimestampToolStripMenuItem.Text = "Show Timestamp";
         this.showTimestampToolStripMenuItem.Click += new System.EventHandler(this.showTimestampToolStripMenuItem_Click);
         // 
         // showInputLogWindowToolStripMenuItem
         // 
         this.showInputLogWindowToolStripMenuItem.Checked = true;
         this.showInputLogWindowToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
         this.showInputLogWindowToolStripMenuItem.Name = "showInputLogWindowToolStripMenuItem";
         this.showInputLogWindowToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
         this.showInputLogWindowToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
         this.showInputLogWindowToolStripMenuItem.Text = "Show Input Log Window";
         this.showInputLogWindowToolStripMenuItem.CheckedChanged += new System.EventHandler(this.showInputLogWindowToolStripMenuItem_CheckedChanged);
         this.showInputLogWindowToolStripMenuItem.Click += new System.EventHandler(this.showInputLogWindowToolStripMenuItem_Click);
         // 
         // hideBlankLinesToolStripMenuItem
         // 
         this.hideBlankLinesToolStripMenuItem.Name = "hideBlankLinesToolStripMenuItem";
         this.hideBlankLinesToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
         this.hideBlankLinesToolStripMenuItem.Text = "Hide Blank Lines";
         this.hideBlankLinesToolStripMenuItem.Click += new System.EventHandler(this.hideBlankLinesToolStripMenuItem_Click);
         // 
         // helpToolStripMenuItem
         // 
         this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
         this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
         this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
         this.helpToolStripMenuItem.Text = "Help";
         // 
         // aboutToolStripMenuItem
         // 
         this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
         this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
         this.aboutToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
         this.aboutToolStripMenuItem.Text = "About";
         this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
         // 
         // lbWriteLog
         // 
         this.lbWriteLog.Dock = System.Windows.Forms.DockStyle.Fill;
         this.lbWriteLog.FormattingEnabled = true;
         this.lbWriteLog.HorizontalScrollbar = true;
         this.lbWriteLog.IntegralHeight = false;
         this.lbWriteLog.Location = new System.Drawing.Point(0, 0);
         this.lbWriteLog.Name = "lbWriteLog";
         this.lbWriteLog.Size = new System.Drawing.Size(833, 42);
         this.lbWriteLog.TabIndex = 5;
         // 
         // textBox1
         // 
         this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.textBox1.Location = new System.Drawing.Point(12, 426);
         this.textBox1.Name = "textBox1";
         this.textBox1.Size = new System.Drawing.Size(345, 20);
         this.textBox1.TabIndex = 6;
         // 
         // btnSend
         // 
         this.btnSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnSend.Location = new System.Drawing.Point(363, 425);
         this.btnSend.Name = "btnSend";
         this.btnSend.Size = new System.Drawing.Size(75, 23);
         this.btnSend.TabIndex = 7;
         this.btnSend.Text = "Send";
         this.btnSend.UseVisualStyleBackColor = true;
         this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
         // 
         // statusStrip1
         // 
         this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslConnectionStatus,
            this.toolStripStatusLabelSeperator,
            this.tsslFiltersSet});
         this.statusStrip1.Location = new System.Drawing.Point(0, 456);
         this.statusStrip1.Name = "statusStrip1";
         this.statusStrip1.Size = new System.Drawing.Size(857, 22);
         this.statusStrip1.TabIndex = 8;
         this.statusStrip1.Text = "statusStrip1";
         // 
         // tsslConnectionStatus
         // 
         this.tsslConnectionStatus.Name = "tsslConnectionStatus";
         this.tsslConnectionStatus.Size = new System.Drawing.Size(71, 17);
         this.tsslConnectionStatus.Text = "Disconnected";
         // 
         // toolStripStatusLabelSeperator
         // 
         this.toolStripStatusLabelSeperator.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
         this.toolStripStatusLabelSeperator.Name = "toolStripStatusLabelSeperator";
         this.toolStripStatusLabelSeperator.Size = new System.Drawing.Size(716, 17);
         this.toolStripStatusLabelSeperator.Spring = true;
         this.toolStripStatusLabelSeperator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
         // 
         // tsslFiltersSet
         // 
         this.tsslFiltersSet.Name = "tsslFiltersSet";
         this.tsslFiltersSet.Size = new System.Drawing.Size(55, 17);
         this.tsslFiltersSet.Text = "Filters Set";
         // 
         // splitContainer1
         // 
         this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                     | System.Windows.Forms.AnchorStyles.Left)
                     | System.Windows.Forms.AnchorStyles.Right)));
         this.splitContainer1.Location = new System.Drawing.Point(12, 76);
         this.splitContainer1.Name = "splitContainer1";
         this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
         // 
         // splitContainer1.Panel1
         // 
         this.splitContainer1.Panel1.Controls.Add(this.lbDataWindow);
         // 
         // splitContainer1.Panel2
         // 
         this.splitContainer1.Panel2.Controls.Add(this.lbWriteLog);
         this.splitContainer1.Size = new System.Drawing.Size(833, 342);
         this.splitContainer1.SplitterDistance = 296;
         this.splitContainer1.TabIndex = 9;
         this.splitContainer1.DoubleClick += new System.EventHandler(this.splitContainer1_DoubleClick);
         this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
         // 
         // btnFilter
         // 
         this.btnFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
         this.btnFilter.Location = new System.Drawing.Point(763, 47);
         this.btnFilter.Name = "btnFilter";
         this.btnFilter.Size = new System.Drawing.Size(82, 21);
         this.btnFilter.TabIndex = 62;
         this.btnFilter.Text = "Data Filter";
         this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
         // 
         // serialPortSelectionControl1
         // 
         this.serialPortSelectionControl1.AutoSize = true;
         this.serialPortSelectionControl1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
         this.serialPortSelectionControl1.Location = new System.Drawing.Point(12, 26);
         this.serialPortSelectionControl1.MinimumSize = new System.Drawing.Size(479, 44);
         this.serialPortSelectionControl1.Name = "serialPortSelectionControl1";
         this.serialPortSelectionControl1.SelectedBaudRate = ((uint)(0u));
         this.serialPortSelectionControl1.SelectedDataBits = ((uint)(8u));
         this.serialPortSelectionControl1.SelectedParity = System.IO.Ports.Parity.None;
         this.serialPortSelectionControl1.SelectedPort = "COM3";
         this.serialPortSelectionControl1.SelectedStopBits = System.IO.Ports.StopBits.One;
         this.serialPortSelectionControl1.Size = new System.Drawing.Size(479, 44);
         this.serialPortSelectionControl1.TabIndex = 0;
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(857, 478);
         this.Controls.Add(this.btnFilter);
         this.Controls.Add(this.splitContainer1);
         this.Controls.Add(this.statusStrip1);
         this.Controls.Add(this.menuStrip1);
         this.Controls.Add(this.btnSend);
         this.Controls.Add(this.textBox1);
         this.Controls.Add(this.serialPortSelectionControl1);
         this.Controls.Add(this.btnClearLogWindow);
         this.Controls.Add(this.cbPauseLog);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.MainMenuStrip = this.menuStrip1;
         this.MinimumSize = new System.Drawing.Size(634, 463);
         this.Name = "Form1";
         this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
         this.Text = "Serial Port Reader/Writer";
         this.Load += new System.EventHandler(this.Form1_Load);
         this.contextMenuStrip1.ResumeLayout(false);
         this.menuStrip1.ResumeLayout(false);
         this.menuStrip1.PerformLayout();
         this.statusStrip1.ResumeLayout(false);
         this.statusStrip1.PerformLayout();
         this.splitContainer1.Panel1.ResumeLayout(false);
         this.splitContainer1.Panel2.ResumeLayout(false);
         this.splitContainer1.ResumeLayout(false);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private ServoControl.SerialPortSelectionControl serialPortSelectionControl1;
      private System.Windows.Forms.ListBox lbDataWindow;
      private System.Windows.Forms.CheckBox cbPauseLog;
      private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
      private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem clearBusLogToolStripMenuItem;
      private System.Windows.Forms.Button btnClearLogWindow;
      private System.Windows.Forms.MenuStrip menuStrip1;
      private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
      private System.Windows.Forms.ListBox lbWriteLog;
      private System.Windows.Forms.TextBox textBox1;
      private System.Windows.Forms.Button btnSend;
      private System.Windows.Forms.StatusStrip statusStrip1;
      private System.Windows.Forms.ToolStripStatusLabel tsslConnectionStatus;
      private System.Windows.Forms.SplitContainer splitContainer1;
      private System.Windows.Forms.ToolStripMenuItem saveLogToolStripMenuItem;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
      private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem showTimestampToolStripMenuItem;
      internal System.Windows.Forms.Button btnFilter;
      private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelSeperator;
      private System.Windows.Forms.ToolStripStatusLabel tsslFiltersSet;
      private System.Windows.Forms.ToolStripMenuItem showInputLogWindowToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem hideBlankLinesToolStripMenuItem;
   }
}

