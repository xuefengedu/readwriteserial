using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Meller.Search;

namespace SerialPortWriterReader.SerialPortReaderWriter
{
   public partial class FindForm : Form
   {
#region Variables
      private TextSearch textSearchHandler = null;
      private int lastFound = -1;
      private ListBox controlToSearch;
#endregion

      public FindForm(ListBox _controlToSearch)
      {
         InitializeComponent();
         controlToSearch = _controlToSearch;
      }

      private void btnClose_Click(object sender, EventArgs e)
      {
         this.Hide();
      }

      private void btnSearch_Click(object sender, EventArgs e)
      {
         if (textSearchHandler == null)
            textSearchHandler = new TextSearch(controlToSearch);

         int found = 0;

         if ((found = textSearchHandler.searchButtonPressed(tbSearchText.Text)) == -1)
            tbSearchText.BackColor = Color.Red;
         else
         {
            if (lastFound > found)
               pbWrap.Visible = true;

            if (lastFound != found)
               controlToSearch.ClearSelected();

            lastFound = found;

            controlToSearch.SelectedIndex = found;
            tbSearchText.BackColor = Color.LightGreen;
         }
      }

      private void FindForm_KeyDown(object sender, KeyEventArgs e)
      {
         if (this.tbSearchText.Visible && e.KeyCode == Keys.Enter)
            btnSearch_Click(null, null);
      }
   }
}