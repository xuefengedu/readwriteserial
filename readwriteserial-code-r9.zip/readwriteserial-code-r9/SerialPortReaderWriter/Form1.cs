using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using Filter_Form;
using SerialPortWriterReader.SerialPortReaderWriter;

namespace SerialPortReader
{
   public partial class Form1 : Form
   {
#region Variables
      private List<string> includeFilterPhrases;
      private List<string> excludeFilterPhrases;
      private FindForm find;
      
      public bool IsInputWindowVisible
      {
         get { return !splitContainer1.Panel2Collapsed; }
         set
         {
            showInputLogWindowToolStripMenuItem.Checked = value;
            splitContainer1.Panel2Collapsed = !value; 
         }
      }

      public bool IsTimeStampShown
      {
         get { return showTimestampToolStripMenuItem.Checked; }
         set { showTimestampToolStripMenuItem.Checked = value; }
      }

      public bool HideBlankLines
      {
         get { return hideBlankLinesToolStripMenuItem.Checked; }
         set { hideBlankLinesToolStripMenuItem.Checked = value; }
      }
#endregion

      public Form1()
      {
         InitializeComponent();

         includeFilterPhrases = new List<string>();
         excludeFilterPhrases = new List<string>();

         find = new FindForm(lbDataWindow);

         AppSettingSave appSaveSetting = new AppSettingSave();

         appSaveSetting.LoadAppSettings(serialPortSelectionControl1, this);

         serialPortSelectionControl1.SerialPortConnectClicked += new EventHandler(OnSerialPortConnected);
      }

      private Thread serialPortReadThread = null;

      public void OnSerialPortConnected(object Sender, EventArgs e)
      {
         if(serialPortReadThread == null)
            serialPortReadThread = new Thread(new ThreadStart(SerialPortReadThread));

         if (serialPortSelectionControl1.SerialPortInUse.IsOpen)
            serialPortReadThread.Start();
         else
         {
            if (serialPortReadThread != null && serialPortReadThread.IsAlive)
            {
               serialPortReadThread.Join(5000);
               serialPortReadThread.Abort();
            }

            serialPortReadThread = null;
         }
      }


      public void SerialPortReadThread()
      {
         while (serialPortSelectionControl1.SerialPortInUse.IsOpen)
         {
            Application.DoEvents();
            Thread.Sleep(500);
            ReadSerialPort();
         }
      }

      private void ReadSerialPort()
      {
         System.IO.Ports.SerialPort serialPort1 = serialPortSelectionControl1.SerialPortInUse;

         try
         {
            if (!serialPort1.IsOpen || serialPort1.BytesToRead == 0)
               return;

            while (serialPort1.IsOpen && serialPort1.BytesToRead > 0)
            {
               if (!serialPortSelectionControl1.SerialPortInUse.IsOpen ||
                    serialPortSelectionControl1.SerialPortInUse.BytesToRead == 0)
                  return;

               string newLine = string.Empty;

               while (serialPortSelectionControl1.SerialPortInUse.IsOpen &&
                      serialPortSelectionControl1.SerialPortInUse.BytesToRead > 0)
               {
                  Application.DoEvents();
                  newLine += serialPortSelectionControl1.SerialPortInUse.ReadLine();

                  if ((newLine.EndsWith("\n") || newLine.EndsWith("\r")) &&
                     !cbPauseLog.Checked && IsBlankAndShouldBeShown(newLine) &&
                     (IncludeNewLine(newLine)) && ExcludeNewLine(newLine))
                  {
                     this.UpdateData(newLine);
                     newLine = string.Empty;
                  }
               }
            }
         }
         catch
         {
         }
      }

      private bool ExcludeNewLine(string newLine)
      {
         return (excludeFilterPhrases.Count == 0 || (excludeFilterPhrases.Count > 0 && checkForExcluded(newLine)));
      }

      private bool IncludeNewLine(string newLine)
      {
         return includeFilterPhrases.Count == 0 || (includeFilterPhrases.Count > 0 && checkForFilter(newLine));
      }

      private bool IsBlankAndShouldBeShown(string newLine)
      {
         newLine = newLine.Trim();
         return !(string.IsNullOrEmpty(newLine) && hideBlankLinesToolStripMenuItem.Checked);
      }
      private bool checkForExcluded(string newLine)
      {
         foreach (string excludeLine in excludeFilterPhrases)
         {
            if(newLine.Contains(excludeLine))
               return false;
         }

         return true;
      }

      private bool checkForFilter(string newLine)
      {
         foreach (string includeLine in includeFilterPhrases)
         {
            if (newLine.Contains(includeLine))
               return true;
         }

         return false;
      }

      private void UpdateData(string newLine)
      {
         if (!this.IsDisposed && this.InvokeRequired)
         {
            UpdateDataCallBack updateDataCB = new UpdateDataCallBack(UpdateDataBoxes);
            this.Invoke(updateDataCB, new string[] { newLine });
         }
         else
            UpdateDataBoxes(newLine);
      }

      delegate void UpdateDataCallBack(string newline);

      private void UpdateDataBoxes(string newLine)
      {
         if (showTimestampToolStripMenuItem.Checked)
            newLine = DateTime.Now.ToString("hh:mm:ss.fff") + ": " + newLine;

         lbDataWindow.Items.Add(newLine.TrimEnd());

         lbDataWindow.SelectedItems.Clear();
         lbDataWindow.SelectedIndex = lbDataWindow.Items.Count - 1;

         int itemsPerPage = (int)(lbDataWindow.Height / lbDataWindow.ItemHeight);
         lbDataWindow.TopIndex = lbDataWindow.Items.Count - itemsPerPage;
      }


      protected override void OnClosing(CancelEventArgs e)
      {
         if (serialPortSelectionControl1.SerialPortInUse != null && 
             serialPortSelectionControl1.SerialPortInUse.IsOpen)
            serialPortSelectionControl1.Disconnect();

         if (serialPortReadThread != null)
         {
            serialPortReadThread.Abort();
            serialPortReadThread.Join(3000);
         }

         base.OnClosing(e);
      }

      protected override void OnClosed(EventArgs e)
      {
         AppSettingSave appSaveSetting = new AppSettingSave();

         appSaveSetting.SaveAppSettings(serialPortSelectionControl1, this);

         base.OnClosed(e);
      }

      private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
      {

      }

      private void toolStripMenuItem_Click(object sender, EventArgs e)
      {
         if (sender.GetType() == typeof(ToolStripMenuItem))
         {
            switch (((ToolStripMenuItem)sender).Name)
            {
               case "copyToolStripMenuItem":
                  Copy();
                  break;
               case "clearToolStripMenuItem":
                  lbDataWindow.Items.Clear();
                  break;
            }
         }
      }

      private void Copy()
      {
         if (lbDataWindow.SelectedItems.Count == 0)
            return;

         string content = "";

         foreach (object obj in lbDataWindow.SelectedItems)
            content += obj.ToString() + "\n";

         Clipboard.SetText(content);
      }

      private void btnClearLogWindow_Click(object sender, EventArgs e)
      {
         lbDataWindow.Items.Clear();
         lbWriteLog.Items.Clear();
      }

      private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
      {
         AboutBox1 ab = new AboutBox1();
         ab.Show();
      }

      private void exitToolStripMenuItem_Click(object sender, EventArgs e)
      {
         serialPortSelectionControl1.Disconnect();
         this.Close();
      }

      private void btnSend_Click(object sender, EventArgs e)
      {
         WriteLineToSerialPort(textBox1.Text);
      }

      private void WriteLineToSerialPort(string outText)
      {
         System.IO.Ports.SerialPort serialPort1 = serialPortSelectionControl1.SerialPortInUse;

         if (serialPort1.IsOpen)
         {
            serialPort1.WriteLine(outText);
            lbWriteLog.Items.Add(outText);
            lbWriteLog.SelectedIndex = lbWriteLog.Items.Count - 1;
         }
      }

      private void lbDataWindow_KeyPress(object sender, KeyPressEventArgs e)
      {
         WriteLineToSerialPort(e.KeyChar.ToString());
      }

      private void lbDataWindow_Enter(object sender, EventArgs e)
      {
         lbDataWindow.BorderStyle = BorderStyle.Fixed3D;
      }

      private void lbDataWindow_Leave(object sender, EventArgs e)
      {
         lbDataWindow.BorderStyle = BorderStyle.FixedSingle;
      }

      private void saveLogToolStripMenuItem_Click(object sender, EventArgs e)
      {
         FileDialog fd = new SaveFileDialog();
         fd.FileName = "SerialPortReaderLog.txt";
         fd.Filter = "Text File (*.txt) | *.txt | All Files (*.*) | *.*";
         fd.AddExtension = true;
         fd.DefaultExt = ".txt";
         fd.Title = "Save Log File";

         if (fd.ShowDialog() == DialogResult.OK)
         {
            FileStream fs = new FileStream(fd.FileName, (FileMode.OpenOrCreate | FileMode.Append));
            StreamWriter sw = new StreamWriter(fs);

            if (fs.CanWrite)
            {
               for (int x = 0; x < lbDataWindow.Items.Count; x++)
                  sw.WriteLine(lbDataWindow.Items[x]);

               sw.Close();
            }

            fs.Close();
         }
      }

      private void findToolStripMenuItem_Click(object sender, EventArgs e)
      {
         if (find.IsDisposed)
            find = new FindForm(lbDataWindow);

         find.Show(this);
      }

      private void btnFilter_Click(object sender, EventArgs e)
      {
         try
         {
            FilterForm ff = new FilterForm();

            if ((includeFilterPhrases != null && includeFilterPhrases.Count > 0) ||
                (excludeFilterPhrases != null && excludeFilterPhrases.Count > 0))
               ff.setFilterPhrases(includeFilterPhrases, excludeFilterPhrases);

            DialogResult dg = ff.ShowDialog();

            if (dg == DialogResult.OK)
            {
               if (includeFilterPhrases == null)
                  includeFilterPhrases = new List<String>();
               if (excludeFilterPhrases == null)
                  excludeFilterPhrases = new List<String>();

               includeFilterPhrases.Clear();
               includeFilterPhrases = ff.getIncludeFilterPhrases();

               excludeFilterPhrases.Clear();
               excludeFilterPhrases = ff.getExcludeFilterPhrases();
               SetFiltersSetLabelVisibility();
            }
         }
         catch (Exception ex)
         {
            MessageBox.Show("(btnFilter_Click) Error: " + ex.Message);
         }
      }

      private void SetFiltersSetLabelVisibility()
      {
         if (includeFilterPhrases.Count > 0 || excludeFilterPhrases.Count > 0)
         {
            tsslFiltersSet.Visible   = true;
            tsslFiltersSet.BackColor = Color.Red;
         }
         else
         {
            tsslFiltersSet.Visible   = false;
            tsslFiltersSet.BackColor = SystemColors.Control;
         }
      }

      private void Form1_Load(object sender, EventArgs e)
      {
         SetFiltersSetLabelVisibility();
      }

      private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
      {
      }

      private void splitContainer1_DoubleClick(object sender, EventArgs e)
      {
         CollapseUncollapsePanel2();
      }

      private void CollapseUncollapsePanel2()
      {
         splitContainer1.Panel2Collapsed = showInputLogWindowToolStripMenuItem.Checked;
      }

      private void showInputLogWindowToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
      {
      }

      private void showInputLogWindowToolStripMenuItem_Click(object sender, EventArgs e)
      {
         CollapseUncollapsePanel2();
         showInputLogWindowToolStripMenuItem.Checked = !showInputLogWindowToolStripMenuItem.Checked;
      }

      private void showTimestampToolStripMenuItem_Click(object sender, EventArgs e)
      {
         showTimestampToolStripMenuItem.Checked = !showTimestampToolStripMenuItem.Checked;
      }

      private void hideBlankLinesToolStripMenuItem_Click(object sender, EventArgs e)
      {
         hideBlankLinesToolStripMenuItem.Checked = !hideBlankLinesToolStripMenuItem.Checked;
      }
   }
}