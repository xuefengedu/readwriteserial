using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Filter_Form
{
   public partial class FilterForm : Form
   {
      public FilterForm()
      {
         InitializeComponent();
      }

      private void btnOk_Click(object sender, EventArgs e)
      {
         Close();
      }

      private void btnRemove_Click(object sender, EventArgs e)
      {
         while (lbIncludeFilterPharses.SelectedItems.Count > 0)
         {
            if (lbIncludeFilterPharses.Items.Count > 0 && lbIncludeFilterPharses.SelectedIndex >= 0)
            {
               int selected = lbIncludeFilterPharses.SelectedIndex;

               lbIncludeFilterPharses.Items.RemoveAt(lbIncludeFilterPharses.SelectedIndex);
            }
         }
         while (lbExcludeFilterPharses.SelectedItems.Count > 0)
         {
            if (lbExcludeFilterPharses.Items.Count > 0 && lbExcludeFilterPharses.SelectedIndex >= 0)
            {
               int selected = lbExcludeFilterPharses.SelectedIndex;

               lbExcludeFilterPharses.Items.RemoveAt(lbExcludeFilterPharses.SelectedIndex);
            }
         }

      }

      private void btnClearAll_Click(object sender, EventArgs e)
      {
         lbIncludeFilterPharses.Items.Clear();
         lbExcludeFilterPharses.Items.Clear();
      }

      public void setFilterPhrases(List<String> includedArray, List<String> excludedArray)
      {
         if (includedArray != null)
         {
            for (int x = 0; x < includedArray.Count; x++)
            {
               if (includedArray[x] != String.Empty)
                  lbIncludeFilterPharses.Items.Add(includedArray[x]);
            }
         }

         if (excludedArray != null)
         {
            for (int x = 0; x < excludedArray.Count; x++)
            {
               if (excludedArray[x] != String.Empty)
                  lbExcludeFilterPharses.Items.Add(excludedArray[x]);
            }
         }
      }

      public List<String> getIncludeFilterPhrases()
      {
         List<String> includedArray = new List<String>();

         try
         {
            if (includedArray != null)
            {
               includedArray.Clear();

               for (int x = 0; x < lbIncludeFilterPharses.Items.Count; x++)
                  includedArray.Add(lbIncludeFilterPharses.Items[x].ToString());
            }
         }
         catch (Exception e)
         {
            MessageBox.Show(this, "Exception In getFilterPhrases: " + e.Message + "\n\nStack: " + e.StackTrace.ToString());
         }

         return includedArray;
      }

      public List<String> getExcludeFilterPhrases()
      {
         List<String> excludedArray = new List<String>();

         try
         {

            if (excludedArray != null)
            {
               excludedArray.Clear();

               for (int x = 0; x < lbExcludeFilterPharses.Items.Count; x++)
                  excludedArray.Add(lbExcludeFilterPharses.Items[x].ToString());
            }
         }
         catch (Exception e)
         {
            MessageBox.Show(this, "Exception In getFilterPhrases: " + e.Message + "\n\nStack: " + e.StackTrace.ToString());
         }

         return excludedArray;
      }

      public void getFilterPhrases(ref List<String> includedArray, ref List<String> excludedArray)
      {
         try
         {
            if (includedArray != null)
            {
               includedArray.Clear();

               for (int x = 0; x < lbIncludeFilterPharses.Items.Count; x++)
                  includedArray.Add(lbIncludeFilterPharses.Items[x].ToString());
            }

            if (excludedArray != null)
            {
               excludedArray.Clear();

               for (int x = 0; x < lbExcludeFilterPharses.Items.Count; x++)
                  excludedArray.Add(lbExcludeFilterPharses.Items[x].ToString());
            }
         }
         catch (Exception e)
         {
            MessageBox.Show(this, "Exception In getFilterPhrases: " + e.Message + "\n\nStack: " + e.StackTrace.ToString());
         }
      }

      protected override void OnKeyDown(KeyEventArgs e)
      {
         if (e.KeyCode == Keys.Enter)
         {
            btnAddIncluded.Focus();
            btnAddIncluded.PerformClick();
            tbAddPhrase.Focus();
         }
         else
         {
            base.OnKeyDown(e);
         }
      }

      private void btnAddExcluded_Click(object sender, EventArgs e)
      {
         if (lbExcludeFilterPharses.Items.Count == 0 || !lbExcludeFilterPharses.Items.Contains(tbAddPhrase.Text))
            lbExcludeFilterPharses.Items.Add(tbAddPhrase.Text);
      }

      private void btnAdd_Click(object sender, EventArgs e)
      {
         if (lbIncludeFilterPharses.Items.Count == 0 || !lbIncludeFilterPharses.Items.Contains(tbAddPhrase.Text))
            lbIncludeFilterPharses.Items.Add(tbAddPhrase.Text);
      }
   }
}