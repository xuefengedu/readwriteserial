using System.Windows.Forms;
using System;
using System.Diagnostics;
using System.Drawing;

namespace Meller.Search
{
   public class TextSearch
   {
      private ListBox searchBox = null;
      private RichTextBox searchRichBox = null;

      private string lastSearchText = "";
      private int lastLine = 0;

      public TextSearch(ListBox searchListBox)
      {
         searchBox = searchListBox;
      }

      public TextSearch(RichTextBox searchRichTextBox)
      {
         searchRichBox = searchRichTextBox;
      }

      public int searchButtonPressed(string searchText)
      {
         int lineFound = -1;

         Trace.WriteLine("Search Text: " + searchText);

         if (searchBox == null)
            return lineFound;

         if (searchText.Length > 0)
         {
            Trace.WriteLine("Calling Find Text");
            lastLine  = searchBox.SelectedIndex;
            lineFound = findText(searchText);
         }

         if (lineFound != -1 && lineFound != searchBox.Items.Count)
         {
            searchBox.SelectedIndex = lineFound;
            // For some reason we need to select line 0 twice so just do it every time a line has been found.
            searchBox.SelectedIndex = lineFound;
         }
         else
         {
            if (searchText.Length > 0)
               lineFound = findText(searchText);

            if (lineFound != -1 && lineFound != searchBox.Items.Count)
            {
               searchBox.SelectedIndex = lineFound;
               // For some reason we need to select line 0 twice so just do it every time a line has been found.
               searchBox.SelectedIndex = lineFound;
            }
         }

         return lineFound;
      }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="text">Text to search for in the list box.</param>
      /// <returns>
      /// -1 - Text was not found on any line or anymore lines.
      /// Otherwise the line that the text string was found on.
      /// </returns>
      public int findText(String text)
      {
         if (searchBox == null)
            return -1;

         Trace.WriteLine("Text: Find");

         if (lastSearchText != text)
         {
            lastSearchText = text;
            Trace.WriteLine("Calling TextFind");
            return textFind(0, searchBox.Items.Count, text);
         }
         else
         {
            int x = -1;

            if (lastLine + 1 < searchBox.Items.Count)
               x = textFind(lastLine + 1, searchBox.Items.Count, text);

            if (x == -1)
               x = textFind(0, lastLine, text);

            return x;
         }
      }


      /// <summary>
      /// This function is used to loop through the entire search box starting at
      /// the given line number and stopping at the given ending line number.
      /// </summary>
      /// <param name="start">Starting line in the search box.</param>
      /// <param name="end">Ending line.</param>
      /// <param name="text">Text to search for.</param>
      /// <returns>
      /// -1 - Text was not found on any line or anymore lines.
      /// Otherwise the line that the text string was found on.
      /// </returns>
      private int textFind(int start, int end, String text)
      {
         int x = 0;

         for (x = start; x < end; x++)
         {
            Trace.WriteLine("Searching for TextFind");
            if (textFound(text, x))
               return x;
         }

         return -1;
      }

      /// <summary>
      /// This function searchs the current box to search and returns true if the text
      /// was found on the line or false if not found.
      /// </summary>
      /// <param name="text">Text to search for on the line.</param>
      /// <param name="x">Line number in the search box.</param>
      /// <returns></returns>
      private bool textFound(String text, int x)
      {
         if (searchBox == null)
            return false;

         String line = searchBox.Items[x].ToString();
         bool found = false;

         //if (!cbRegExp.Checked)
         {
            if (line.Contains(text))
            {
               lastLine = x;
               found = true;
            }
         }
         //else
         //{
         //   if (System.Text.RegularExpressions.Regex.IsMatch(line, text))
         //   {
         //      lastLine = x;
         //      found = true;
         //   }
         //}
         return found;
      }
   }
}